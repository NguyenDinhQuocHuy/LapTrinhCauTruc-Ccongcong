#include <iostream>
#include <conio.h>

using namespace std;
// Hang so
#define TAB "\t"
// Khai bao nguyen mau ham
int LaSoNT(int n);
void LietKeSoNT(unsigned int n);
// Khai bao ham main
int main()
{
	unsigned int n;
	cout << endl << "Nhap so luong so nguyen to can tim: ";
	cin >> n;
	LietKeSoNT(n);

	_getch();
	return 0;
}

// Dinh nghia ham

// Dinh nghia ham kiem tra n co phai so nguyen to hay ko?
int LaSoNT(int n)
{
	if (n < 2)
		return 0;
	else
	{
		int m = (int)sqrt((float)n), i = 2, kq = 1;
		while (i <= m && kq)
		{
			kq = n % i;
			i++;
		}
		return kq;
	}
}

// Dinh nghia ham tim n so nguyen to dau tien
void LietKeSoNT(unsigned int n)
{
	int dem = 0, so = 2;
	while (dem < n)
	{
		if (LaSoNT(so))
		{
			cout << so << TAB;
			dem++;
		}
		so++;
	}
}
