#include <iostream>
#include <conio.h>

using namespace std;

// Khai bao nguyen mau ham
unsigned short NhapDiem(int stt);
void ThongKe(unsigned int n);
// Khai bao ham main
int main()
{
	unsigned int n;
	cout << endl << "Nhap so luong sinh vien: "; cin >> n;

	ThongKe(n);

	_getch();
	return 0;
}

// Dinh nghia ham
// 
// Dinh nghia ham nhap diem tu ban phim
unsigned short NhapDiem(int stt)
{
	unsigned short diem;
	do
	{
		cout << endl << "Nhap diem cua sinh vien thu " << stt << " : ";
		cin >> diem;
	} while (diem < 0 || diem > 10);
	return diem;
}

// Dinh nghia ham thong ke
void ThongKe(unsigned int n)
{
	int d0 = 0, d1 = 0, d2 = 0, d3 = 0, d4 = 0, d5 = 0, d6 = 0, d7 = 0, d8 = 0, d9 = 0, d10 = 0;
	unsigned short diem;

	for (int i = 0; i <= n; i++)
	{
		diem = NhapDiem(i + 1);
		switch (diem)
		{
		case 10: d10++;
		case 9: d9++;
		case 8: d8++;
		case 7: d7++;
		case 6: d6++;
		case 5: d5++;
		case 4: d4++;
		case 3: d3++;
		case 2: d2++;
		case 1: d1++;
		case 0: d0++;
		}
	}
	cout << endl << "So sinh vien co diem >= 0 la: " << d0;
	cout << endl << "So sinh vien co diem >= 1 la: " << d1;
	cout << endl << "So sinh vien co diem >= 2 la: " << d2;
	cout << endl << "So sinh vien co diem >= 3 la: " << d3;
	cout << endl << "So sinh vien co diem >= 4 la: " << d4;
	cout << endl << "So sinh vien co diem >= 5 la: " << d5;
	cout << endl << "So sinh vien co diem >= 6 la: " << d6;
	cout << endl << "So sinh vien co diem >= 7 la: " << d7;
	cout << endl << "So sinh vien co diem >= 8 la: " << d8;
	cout << endl << "So sinh vien co diem >= 9 la: " << d9;
	cout << endl << "So sinh vien co diem >= 10 la: " << d10;
}