#include <iostream>
#include <iomanip>
#include <math.h>
#include <conio.h>

using namespace std;

// Khai bao nguyen mau ham
int PhanLoaiTamGiac(double a, double b, double c);
void ThongBao(int loaiTG, double a, double b, double c);

// Khai bao ham main
int main()
{
	double a, b, c;
	cout << endl << "Nhap do dai 3 canh a, b, c: "; cin >> a >> b >> c;

	int ketQua = PhanLoaiTamGiac(a, b, c);
	ThongBao(ketQua, a, b, c);

	_getch();
	return 0;
}

// Dinh nghia ham

// Dinh nghia ham phan loai tam giac
/*
1: Neu a, b, c la 3 canh cua tam giac deu
2: Neu a, b, c la 3 canh cua tam giac can
3: Neu a, b, c la 3 canh cua tam giac vuong
4: Neu a, b, c la 3 canh cua tam giac vuong can
5: Neu a, b, c la 3 canh cua tam giac thuong
0: Neu a, b, c khong phai la 3 canh cua tam giac
*/
int PhanLoaiTamGiac(double a, double b, double c)
{
	int kq = 0;

	if (a + b > c || a + c > b || b + c > a)
	{
		// Neu 3 canh bang nhau thi la tam giac deu
		if (a == b && b == c)
			kq = 1;
		else if (a == b || b == c || a == c)
		{
			// Tam giac vuong can ?
			if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
				kq = 4;
			// Tam giac can
			else
				kq = 2;
		}
		else  // Kiem tra tam giac vuong hay khong ?
			if (a * a + b * b == c * c || a * a + c * c == b * b || b * b + c * c == a * a)
				kq = 3; // Tam giac vuong
			else
				kq = 5; // Tam giac thuong


	}
	else
		kq = 0;
	return kq;

}

// Dinh nghia ham thong bao ket qua phan loai tam giac
void ThongBao(int loaiTG, double a, double b, double c)
{
	switch (loaiTG)
	{
	case 0: cout << endl << a << ", " << b << ", " << c << " khong phai la 3 canh cua tam giac !";
		break;
	case 1: cout << endl << a << ", " << b << ", " << c << " la 3 canh cua 1 tam gac deu";
		break;
	case 2: cout << endl << a << ", " << b << ", " << c << " la 3 canh cua 1 tam giac can";
		break;
	case 3: cout << endl << a << ", " << b << ", " << c << " la 3 canh cua 1 tam giac vuong";
		break;
	case 4: cout << endl << a << ", " << b << ", " << c << " la 3 canh cua 1 tam giac vuong can";
		break;
	case 5: cout << endl << a << ", " << b << ", " << c << " la 3 canh cua 1 tam giac thuong";
		break;
	}
}