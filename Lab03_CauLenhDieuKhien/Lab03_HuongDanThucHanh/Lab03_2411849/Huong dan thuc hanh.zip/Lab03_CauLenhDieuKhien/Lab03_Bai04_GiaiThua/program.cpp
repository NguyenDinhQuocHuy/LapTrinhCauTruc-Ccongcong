#include <iostream>
#include <iomanip>
#include <conio.h>
#include <math.h>

using namespace std;

// Khai bao nguyen mau ham
long TinhGiaiThua(unsigned int n);
long TinhTong(unsigned int n);

int main()
{
	unsigned int n;
	long ketQua;

	cout << endl << "Nhap mot so nguyen khong am: "; cin >> n;
	ketQua = TinhGiaiThua(n);
	cout << endl << n << "! = " << ketQua;

	ketQua = TinhTong(n);
	cout << endl << "1 + 2 + 3 + ... + n = " << ketQua;

	_getch();
	return 0;
}

// Dinh nghia ham

// Tinh Giai thua
long TinhGiaiThua(unsigned int n)
{
	if (n < 2)
		return 1;
	else
	{
		long kq = 1;
		for (int i = 2; i <= n; i++)
			kq *= i;
		return kq;
	}
}

// Tinh tong
long TinhTong(unsigned int n)
{
	long sum = 0;
	for (int i = 1; i <= n; i++)
		sum += 1;
	return sum;
}

