 // Phan huong dan
 
 // Nap cac thu vien ham vao phuong trinh
 #include <iostream>
 #include <conio.h>
 
 using namespace std;
 
 // Dinh nghia hang so va cac kieu du lieu moi
 
 // Khai bao nguyen mau ham
 
 // Dinh nghia ham main
 int main()
 {
 	
 	
 	_getch();
 	return 0;
 }
 
 // Dinh nghia cac ham xu ly
 
 // Dinh nghia ham nhap mot so khac khong tu ban phim
 float NhapMotSoKhacKhong()
 {
 	float so;
 	do
 	{
 		cout << endl << "Nhap mot so khac 0: "; cin >> so;
 		
	} while (so == 0);
	
	return so;
 }
 
 // Dinh nghia ham gia phuong trinh bac 2
 void GiaiPhuongTrinhBacHai(float a, float b, float c)
 {
 	double delta,x;
 	
 	delta = b * b - 
 	
 }
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
