// Phan huong dan

 // Nap cac thu vien ham vao phuong trinh
#include <iostream>
#include <conio.h>
#include <math.h>
#include <iomanip>

using namespace std;

// Dinh nghia hang so va cac kieu du lieu moi

// Khai bao nguyen mau ham
float NhapMotSoKhacKhong();
void GiaiPhuongTrinhBacHai(float a, float b, float c);

// Dinh nghia ham main
int main()
{
    float a, b, c;
    a = NhapMotSoKhacKhong();
    cout << endl << "Nhap he so b: "; cin >> b;
    cout << endl << "Nhap he so c: "; cin >> c;

    GiaiPhuongTrinhBacHai(a, b, c);

    _getch();
    return 0;
}

// Dinh nghia cac ham xu ly

 // Dinh nghia ham nhap mot so khac khong tu ban phim
float NhapMotSoKhacKhong()
{
    float so;
    do
    {
        cout << endl << "Nhap mot so khac 0: "; cin >> so;

    } while (so == 0);

    return so;
}

// Dinh nghia ham gia phuong trinh bac 2
void GiaiPhuongTrinhBacHai(float a, float b, float c)
{
    double delta, x;

    delta = b * b - 4 * a * c;

    if (delta < 0)
    {
        cout << endl << "Phuong trinh vo nghiem";
    }
    else if (delta == 0)
    {
        x = -b / (2 * a);
        cout << endl << "Phuong trinh co nghiem kep la: x = " << x;

    }
    else
    {
        cout << "Phuong trinh co 2 nghiem phan biet: ";
        x = (-b + sqrt(delta)) / (2 * a);
        cout << "x1 = " << fixed << setprecision(5) << x;
        x = (-b - sqrt(delta)) / (2 * a);
        cout << endl << "x2 = " << fixed << setprecision(5) << x;

    }
    


}